lm35.o: ..\V25HE10C4_ARM\lm35.c
lm35.o: ..\V25HE10C4_ARM\types.h
lm35.o: ..\V25HE10C4_ARM\adc.h
lm35.o: ..\V25HE10C4_ARM\types.h
