# ThermoSet Connect — Version 2 Source Package

This package revises the working ThermoSet Connect project using the supplied old menu implementation as the menu/input reference.

## What was changed

1. **Old tested keypad input flow retained**
   - Uses the existing `keyscan()` and `ReadNUM()` functions.
   - Retains `NEXT_OPT`, `PREV_OPT`, `INPUT_CANCEL`, and `INPUT_EMPTY` behavior through the project's current `READNUM_*` aliases.
   - Menu pages:
     - `1:Time 2:Date`
     - `3:SP N:Next`
     - `4:Prev SP`
     - `P:Prev C:Exit`

2. **Four requested menu functions**
   - Time
   - Date
   - Setpoint
   - Previous setpoint

3. **EEPROM setpoint history**
   - Current setpoint: `0x0000`
   - Previous setpoint: `0x0001`
   - Default setpoint: `30`
   - Valid range: `1..99`
   - Previous/current values are kept in RAM and persisted to EEPROM.

4. **Remote setpoint update without reset**
   - Cloud setpoint is checked periodically (`90 s`).
   - If unchanged, LCD reports `SP unchanged`.
   - If changed, previous/current setpoints are updated, EEPROM is written, and the alarm state is immediately re-evaluated on the next loop.
   - No reset is required.

5. **LCD status messages**
   - Startup
   - Wi-Fi connection
   - Cloud checking
   - Cloud update
   - Update success/failure
   - Normal time / temperature / setpoint display

6. **Normal LCD screen**
   - Line 1: RTC time + current setpoint
   - Line 2: current temperature + `OK` / `ALERT` / silenced alert status

7. **Buzzer logic**
   - Alert condition is `temperature > setpoint`.
   - Temperature equal to or below setpoint is not an alert.
   - `BUZZER_ACTIVE_HIGH` is set to `1` to match the current source behavior. Change it to `0` only if your physical buzzer is active-low.

8. **ESP receive buffer preserved**
   - The existing global `t[]` receive buffer and current response parsing mechanism were not replaced.
   - `waitforresponse()` remains based on the existing buffer.
   - TCP connections are explicitly closed after ThingSpeak transactions to make subsequent `CIPSTART` operations cleaner.

## Keil project note

The original Keil project references these driver sources outside this folder:

`..\\V25HE10C4_ARM\\delay.c`
`..\\V25HE10C4_ARM\\adc.c`
`..\\V25HE10C4_ARM\\kpm.c`
`..\\V25HE10C4_ARM\\lcd.c`
`..\\V25HE10C4_ARM\\lm35.c`
`..\\V25HE10C4_ARM\\uart.c`

Those source files were not present in the supplied project ZIP, so this package does not invent replacement drivers. Keep your existing `V25HE10C4_ARM` folder at the path expected by `ThermoSet.uvproj`.

## Important hardware behavior

- EINT2 switch requests the local menu.
- The keypad is used inside the menu.
- A keypad press while an active alarm is sounding silences the buzzer; the alert LED remains on while the temperature is above the setpoint.
- Cloud operation is optional at runtime: if Wi-Fi connection fails, local temperature, alarm, RTC, EEPROM, and menu functions continue.

## Verification status

The modified source files were checked for balanced braces/parentheses and obvious structural issues. A Keil/ARMCC compiler was not available in this environment, so the package was **not** claimed as a completed hardware build. Please build it with the same Keil toolchain used for the original project and test on the LPC2148 hardware.
