lcd.o: ..\V25HE10C4_ARM\lcd.c
lcd.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
lcd.o: ..\V25HE10C4_ARM\types.h
lcd.o: ..\V25HE10C4_ARM\delay.h
lcd.o: ..\V25HE10C4_ARM\lcd_defines.h
lcd.o: ..\V25HE10C4_ARM\defines.h
