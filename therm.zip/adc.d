adc.o: ..\V25HE10C4_ARM\adc.c
adc.o: ..\V25HE10C4_ARM\delay.h
adc.o: ..\V25HE10C4_ARM\types.h
adc.o: C:\KeilARM\ARM\INC\Philips\lpc21xx.h
adc.o: ..\V25HE10C4_ARM\defines.h
adc.o: ..\V25HE10C4_ARM\adc_defines.h
