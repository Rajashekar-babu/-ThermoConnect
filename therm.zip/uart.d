uart.o: ..\V25HE10C4_ARM\uart.c
uart.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.h
uart.o: ..\V25HE10C4_ARM\types.h
uart.o: ..\V25HE10C4_ARM\uart_defines.h
uart.o: C:\KeilARM\ARM\RV31\INC\string.h
uart.o: ..\V25HE10C4_ARM\delay.h
uart.o: ..\V25HE10C4_ARM\lcd.h
uart.o: ..\V25HE10C4_ARM\types.h
