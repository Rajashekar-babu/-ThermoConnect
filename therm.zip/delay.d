delay.o: ..\V25HE10C4_ARM\delay.c
delay.o: ..\V25HE10C4_ARM\delay.h
